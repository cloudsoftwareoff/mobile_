package com.exam.ex1;

interface Identitie {

public abstract String toString();
public abstract boolean equals(Object x);

}
